# Quick Start Guide - PawHaven Django Project

## 🚀 Getting Started in 3 Steps

### Step 1: Navigate to Project Directory
```bash
cd /home/claude
```

### Step 2: Start the Development Server
```bash
python manage.py runserver 8000
```

### Step 3: Open Your Browser
- **Main Website:** http://localhost:8000
- **Admin Panel:** http://localhost:8000/admin
  - Username: `admin`
  - Password: `admin123`

## 🎯 What You Can Do Now

### View the Website
1. Browse pets at: http://localhost:8000/pets/
2. View individual pet details
3. Use filters to search (by type, size, etc.)
4. Submit contact form
5. Read about the shelter

### Manage Content (Admin Panel)
1. Go to http://localhost:8000/admin
2. Login with admin/admin123
3. Click "Pets" to add/edit/delete pets
4. Upload pet images
5. View contact form submissions
6. Manage adoption applications

## 📝 Common Tasks

### Add a New Pet
1. Go to Admin → Pets → Add Pet
2. Fill in all required fields
3. Upload images (optional)
4. Check "Featured" to show on homepage
5. Click "Save"

### Change Site Colors
Edit `/home/claude/shelter/static/shelter/css/style.css`:
```css
:root {
    --primary-color: #2E8B57;    /* Your main color */
    --secondary-color: #FFB347;  /* Accent color */
}
```

### Create More Sample Data
```bash
python manage.py shell
```
Then:
```python
from shelter.models import Pet
from datetime import date

pet = Pet.objects.create(
    name="Fluffy",
    type="cat",
    breed="Persian",
    age="3 years",
    gender="Female",
    size="Medium",
    color="White",
    description="A beautiful Persian cat looking for a loving home.",
    personality=["Gentle", "Quiet", "Affectionate"],
    vaccinated=True,
    spayed_neutered=True,
    microchipped=True,
    special_needs=False,
    status="available",
    arrival_date=date(2024, 10, 1),
    adoption_fee=200,
    featured=True
)
print(f"Created {pet.name}!")
```

## 🎨 Customization

### Add Your Logo
1. Save logo as: `shelter/static/shelter/images/icons/logo.png`
2. Size: 50x50 pixels
3. Refresh the page

### Add Pet Images
Option 1: Through Admin
- Go to Admin → Pets → Edit a pet
- Upload image in "Main image" field

Option 2: Programmatically
```python
# In Django shell
from shelter.models import Pet
pet = Pet.objects.get(name="Bella")
# Then upload through admin or use ImageField methods
```

## 🔧 Useful Commands

```bash
# Create new migrations after model changes
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create superuser (admin account)
python manage.py createsuperuser

# Open Django shell (Python console with Django loaded)
python manage.py shell

# Collect static files (for production)
python manage.py collectstatic

# Run on different port
python manage.py runserver 8080
```

## 📁 Important Files

- **Models:** `shelter/models.py` - Database structure
- **Views:** `shelter/views.py` - Business logic
- **URLs:** `shelter/urls.py` - URL routing
- **Templates:** `shelter/templates/shelter/` - HTML files
- **CSS:** `shelter/static/shelter/css/` - Styles
- **JS:** `shelter/static/shelter/js/` - JavaScript

## ❓ Troubleshooting

**Server won't start?**
- Check if port 8000 is already in use
- Try a different port: `python manage.py runserver 8080`

**Static files not loading?**
```bash
python manage.py collectstatic
```

**Database errors?**
```bash
# Reset database (WARNING: Deletes all data)
rm db.sqlite3
python manage.py migrate
```

**Can't login to admin?**
```bash
python manage.py createsuperuser
```

## 🎓 Next Steps

1. ✅ Add real pet images
2. ✅ Customize colors and branding
3. ✅ Add your own content
4. ✅ Test the adoption application form
5. ✅ Configure email notifications (see README.md)
6. ✅ Deploy to production server

## 📚 Learn More

- Full documentation: See `README.md`
- Django docs: https://docs.djangoproject.com/
- Django tutorial: https://docs.djangoproject.com/en/stable/intro/tutorial01/

---

**Everything is ready to go! Start the server and explore your Django pet shelter! 🐾**
